﻿using System;

namespace NumberToWordConvertor
{
    class Program
    {
        static void Main(string[] args)
        {
            string strNumber;
            int intNumber;
            bool isValid;
            bool isUK = true;
            Console.WriteLine("\nEnter '0' to quit the program at any time\n");
            
            do
            {
                Console.Write("Enter integer : ");
                strNumber = Console.ReadLine();
                isValid = int.TryParse(strNumber, out intNumber);
                if (!isValid)
                    Console.WriteLine("\n  Not an integer, please try again\n");
                else
                    Console.WriteLine("\n  {0}\n", NumberToText(intNumber, isUK));
            }
            while (!(isValid && intNumber == 0));
            Console.WriteLine("\nProgram ended");
        }
        public static string NumberToText(int intNumber, bool isUK)
        {
            if (intNumber == 0) return "Zero";

            string and = isUK ? "and " : ""; // deals with UK or US intNumbering
            if (intNumber == -2147483648) return "Minus Two Billion One Hundred " + and +
            "Forty Seven Million Four Hundred " + and + "Eighty Three Thousand " +
            "Six Hundred " + and + "Forty Eight";
            int[] num = new int[4];
            int first = 0;
            int intUnitsNumber, intHundredsNumber, inThousandsNumber;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (intNumber < 0)
            {
                sb.Append("Minus ");
                intNumber = -intNumber;
            }
            string[] words0 = { "", "One ", "Two ", "Three ", "Four ", "Five ", "Six ", "Seven ", "Eight ", "Nine " };
            string[] words1 = { "Ten ", "Eleven ", "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ", "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen " };
            string[] words2 = { "Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ", "Seventy ", "Eighty ", "Ninety " };
            string[] words3 = { "Thousand ", "Million ", "Billion " };
            num[0] = intNumber % 1000;           // units
            num[1] = intNumber / 1000;
            num[2] = intNumber / 1000000;
            num[1] = num[1] - 1000 * num[2];  // thousands
            num[3] = intNumber / 1000000000;     // billions
            num[2] = num[2] - 1000 * num[3];  // millions
            for (int i = 3; i > 0; i--)
            {
                if (num[i] != 0)
                {
                    first = i;
                    break;
                }
            }
            for (int i = first; i >= 0; i--)
            {
                if (num[i] == 0) continue;
                intUnitsNumber = num[i] % 10;              // ones
                inThousandsNumber = num[i] / 10;
                intHundredsNumber = num[i] / 100;             // hundreds
                inThousandsNumber = inThousandsNumber - 10 * intHundredsNumber;               // tens
                if (intHundredsNumber > 0) sb.Append(words0[intHundredsNumber] + "Hundred ");
                if (intUnitsNumber > 0 || inThousandsNumber > 0)
                {
                    if (intHundredsNumber > 0 || i < first) sb.Append(and);
                    if (inThousandsNumber == 0)
                        sb.Append(words0[intUnitsNumber]);
                    else if (inThousandsNumber == 1)
                        sb.Append(words1[intUnitsNumber]);
                    else
                        sb.Append(words2[inThousandsNumber - 2] + words0[intUnitsNumber]);
                }
                if (i != 0) sb.Append(words3[i - 1]);
            }
            return sb.ToString().TrimEnd();

        }
    }
}
